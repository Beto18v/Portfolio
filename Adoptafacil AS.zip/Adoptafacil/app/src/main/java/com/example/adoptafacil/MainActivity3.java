package com.example.adoptafacil;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity3 extends AppCompatActivity {

    private ImageView ivDetailPetImage;
    private TextView tvDetailPetName;
    private TextView tvDetailPetBreed;
    private TextView tvDetailPetAge;
    private TextView tvDetailPetDescription;
    private Button btnAdopt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        ivDetailPetImage = findViewById(R.id.ivDetailPetImage);
        tvDetailPetName = findViewById(R.id.tvDetailPetName);
        tvDetailPetBreed = findViewById(R.id.tvDetailPetBreed);
        tvDetailPetAge = findViewById(R.id.tvDetailPetAge);
        tvDetailPetDescription = findViewById(R.id.tvDetailPetDescription);
        btnAdopt = findViewById(R.id.btnAdopt);

        String petName = getIntent().getStringExtra("pet_name");
        if (petName != null && !petName.isEmpty()) {
            tvDetailPetName.setText(petName);
            if (petName.equals("Max")) {
                ivDetailPetImage.setImageResource(R.drawable.perro);
                tvDetailPetBreed.setText("Raza: Labrador");
                tvDetailPetAge.setText("Edad: 2 años");
                tvDetailPetDescription.setText("Max es un labrador muy enérgico y leal. Le encanta jugar a la pelota y es muy bueno con los niños. Ha sido vacunado y desparasitado.");
            } else if (petName.equals("Luna")) {
                ivDetailPetImage.setImageResource(R.drawable.gato);
                tvDetailPetBreed.setText("Raza: Siamés");
                tvDetailPetAge.setText("Edad: 1 año");
                tvDetailPetDescription.setText("Luna es una gata siamesa muy elegante y tranquila. Disfruta de las siestas al sol y es muy independiente. Busca un hogar tranquilo.");
            }

        btnAdopt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity3.this, "Iniciando proceso de adopción...", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(MainActivity3.this, MainActivity4.class);
                intent.putExtra("pet_to_adopt", tvDetailPetName.getText().toString());
                startActivity(intent);
            }
        });
    }
}}