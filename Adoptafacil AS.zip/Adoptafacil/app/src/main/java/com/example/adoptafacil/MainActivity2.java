package com.example.adoptafacil;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity2 extends AppCompatActivity {

    private Spinner spinnerPetType;
    private ImageView ivPetImage;
    private TextView tvPetName;
    private TextView tvPetDescription;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        spinnerPetType = findViewById(R.id.spinnerPetType);
        ivPetImage = findViewById(R.id.ivPetImage);
        tvPetName = findViewById(R.id.tvPetName);
        tvPetDescription = findViewById(R.id.tvPetDescription);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this,
                R.array.pet_types,
                android.R.layout.simple_spinner_item
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerPetType.setAdapter(adapter);

        // Listener para la selección de elementos en el Spinner
        spinnerPetType.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedPetType = parent.getItemAtPosition(position).toString();
                // Muestra un Toast
                Toast.makeText(MainActivity2.this, "Filtrando por: " + selectedPetType, Toast.LENGTH_SHORT).show();

                if (selectedPetType.equals("Perros")) {
                    ivPetImage.setImageResource(R.drawable.perro);
                    tvPetName.setText("Max");
                    tvPetDescription.setText("Un perro amigable y juguetón, ideal para familias.");
                } else if (selectedPetType.equals("Gatos")) {
                    ivPetImage.setImageResource(R.drawable.gato);
                    tvPetName.setText("Luna");
                    tvPetDescription.setText("Una gata tranquila y cariñosa, le encanta dormir.");
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        // Listener para la imagen de la mascota
        ivPetImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity2.this, "Ver detalles de la mascota", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(MainActivity2.this, MainActivity3.class);
                intent.putExtra("pet_name", tvPetName.getText().toString());
                startActivity(intent);
            }
        });
    }
}