package com.example.adoptafacil;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity5 extends AppCompatActivity {

    private TextView tvConfirmationMessage;
    private TextView tvSummaryDetails;
    private Button btnGoHome;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main5);

        tvConfirmationMessage = findViewById(R.id.tvConfirmationMessage);
        tvSummaryDetails = findViewById(R.id.tvSummaryDetails);
        btnGoHome = findViewById(R.id.btnGoHome);

        String applicantName = getIntent().getStringExtra("applicant_name");
        String petAdopted = getIntent().getStringExtra("pet_adopted");

        if (applicantName != null && !applicantName.isEmpty() && petAdopted != null && !petAdopted.isEmpty()) {
            tvConfirmationMessage.setText("¡Gracias por tu solicitud, " + applicantName + "!");
            tvSummaryDetails.setText("Hemos recibido tu solicitud para adoptar a " + petAdopted + ".\nNos pondremos en contacto contigo pronto.");
        } else {
            tvConfirmationMessage.setText("¡Solicitud Recibida!");
            tvSummaryDetails.setText("Tu solicitud de adopción ha sido enviada. Gracias por tu interés.");
        }

        btnGoHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity5.this, "Volviendo al inicio...", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(MainActivity5.this, MainActivity1.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                finish();
            }
        });
    }
}